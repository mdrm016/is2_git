====================================================
 celery.app.builtins
====================================================

.. contents::
    :local:
.. currentmodule:: celery.app.builtins

.. automodule:: celery.app.builtins
    :members:
    :undoc-members:
