========================================
 celery._state
========================================

.. contents::
    :local:
.. currentmodule:: celery._state

.. automodule:: celery._state
    :members:
    :undoc-members:
